/*
    2023.06.09 AM 11:36  
    這一份程式碼"沒有"拆分檔案
    製作大專前，請務必將檔案先拆分，確認路徑引用等等在執行
*/
var express = require('express');
var app = express();

// mysql套件 + 啟動套件 => 為了要去資料庫拿資料
var mysql = require('mysql');
var pikachu = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'lab2023',
    multipleStatements: true
})
pikachu.connect(function (err) {
    if (err) {
        console.log('資料庫連線失敗', err)
    } else {
        console.log('資料庫連線成功')
    }
})

// 引用+啟動 express-session 套件
// 詳細說明請看 第11章 第7頁
//  => 
var expressSession = require('express-session');
var s = expressSession({
    secret: 'pikachu',
    resave: true,
    saveUninitialized: true,
    cookie: {
        path: '/',
        httpOnly: true,
        secure: false,
        maxAge: 50 * 1000
    }
});
app.use(s);

// AM 11:36
// 訂單 => 回傳 ejs
// 其實這裡做了兩件事情
// 我要怎麼樣讓路由碰到的時候，可以去執行兩件事情
var apple = ""
function checkisLogin(req, res, next) {
    res.locals.Monday = "星期一";
    // PM 13:48 回到分頁的那一天，可以先在這裡取得資料表總筆數
    // select count(*) from inventory
    res.locals.tableRows = 28;
    next();
}

// AM 11:36
function getOrderList(req, res) {
    res.locals.Tuesday = "星期二";
    console.log(res.locals.Tuesday);
   
    // 想要證明可以取得在另外一個 function 的紀錄
    console.log(res.locals.Monday);
   
    res.render('order.ejs', {
        cat: "菜菜",
        // PM 13:48 回到分頁的那一天，在這裡取得總筆數
        orange: res.locals.tableRows / 3
    });
}

// AM 11:36
app.get('/order', [checkisLogin, getOrderList])

// AM 11:36
function getPokemonList(req, res) {
    var sql = 'select * from pokemon';
    pikachu.query(sql, function (err, data) {
        if (err) {
            res.send('無法取得神奇寶貝')
        } else {
            res.render('pokemon.ejs', {
                apple: "蘋果",
                pokeData: data,
                id: req.session.AABBCC.id,
                member_name: req.session.AABBCC.member_name,
                userData: req.session.AABBCC
            });
        }
    })
}

// 首頁 => 回傳 ejs
app.get('/', function (req, res) {
    
    console.log(res.locals.Monday);
    console.log(res.locals.Tuesday);

    res.render('index.ejs');
})

// 登入 => 回傳 ejs
app.get('/login', function (req, res) {
    res.render('login.ejs');
})

// // AM 10:00 寶可夢 => (就算沒登入也可以) 回傳 ejs
// // AM 10:51 寶可夢 => (要判斷有登入才)   回傳 ejs
// // AM 11:16 加入部分使用者資料去 ejs
// app.get('/pokemon', function (req, res) {
//     console.log('測試session =====> ', req.session); // {}

//     // AM 10:51 加入 session 判斷
//     if (req.session.AABBCC) {
//         // AM 10:34 取得資料庫資料=>ejs網頁
//         var sql = 'select * from pokemon';
//         pikachu.query(sql, function (err, data) {
//             // // 只是想查看資料，查看完了就註解掉
//             // console.log(data);
//             if (err) {
//                 res.send('無法取得神奇寶貝')
//             } else {
//                 res.render('pokemon.ejs', {
//                     apple: "蘋果",
//                     pokeData: data,
//                     // AM 11:24 在後端挑選資料 (二選一)
//                     id: req.session.AABBCC.id,
//                     member_name: req.session.AABBCC.member_name,

//                     // AM 11:24 把全部資料交給ejs處理 (二選一)
//                     userData: req.session.AABBCC
//                 });
//             }
//         })
//     } else {
//         // AM 10:51 如果沒登入就導向登入*路由*
//         res.redirect('/login');
//     }
// })

// AM 11:36
app.get('/pokemon', [checkisLogin, getPokemonList])


// 註冊 => 回傳 ejs
app.get('/register', function (req, res) {
    res.render('register.ejs');
})

// 新增一筆資料到資料庫 => 成功跳到首頁 => 請思考你專案想跳到哪裡
app.post('/register', express.urlencoded(), function (req, res) {
    console.log(req.body);
    console.log(req.body.member_name);
    console.log(req.body.member_password);
    var sql = "INSERT INTO member ( member_name , member_password) VALUES (?, ?);";
    var userInput = [req.body.member_name, req.body.member_password];
    pikachu.query(sql, userInput, function (err, data) {
        if (err) {
            res.send('無法新增')
        } else {
            res.redirect('/');
        }
    })
})

// 嘗試登入系統 => 成功跳到寶可夢 => 請思考你專案想跳到哪裡
app.post('/login', express.urlencoded(), function (req, res) {
    var sql = "SELECT * FROM member m where m.member_name = ? and m.member_password = ? ";
    var userInput = [req.body.member_name, req.body.member_password];
    pikachu.query(sql, userInput, function (err, data) {
        console.log(data[0]);

        // AM 10:23 因為select不到資料不算錯誤
        if (err == null && data.length == 1) {

            // AM 10:51 記錄使用者登入的資訊，給 /pokemon 使用
            // AM 11:16 我要記錄使用者的個人訊息
            req.session.AABBCC = data[0];

            res.redirect('/pokemon');
        } else {
            res.send('登入失敗')
        }
    })
})

// 啟動服務
app.listen(3000, function () {
    console.clear();
    console.log('啟動中 ' + new Date().toLocaleTimeString());
})