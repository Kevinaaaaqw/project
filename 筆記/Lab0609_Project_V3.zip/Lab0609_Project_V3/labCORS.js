/*
    2023.06.09 
    上課討論使用
    經過判斷有不合理的地方請自由修改
*/
var express = require('express');
var app = express();

// 底下的程式碼來自 第18章第10頁
// 詳細的設定，可參考第18章第17頁
var cors = require('cors');
var c = cors();
app.use(c);

// mysql套件 + 啟動套件 => 為了要去資料庫拿資料
var mysql = require('mysql');
var pikachu = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'lab2023',
    multipleStatements: true
})
pikachu.connect(function (err) {
    if (err) {
        console.log('資料庫連線失敗', err)
    } else {
        console.log('資料庫連線成功')
    }
})

// PM 14:45 我想要共享寶可夢資料出去
app.get('/pokemon', function (req, res) {
    var sql = 'select * from pokemon';
    pikachu.query(sql, function(err, data){
        if (err) {
            res.send('抱歉，資料有問題');
        } else {
            res.json(data);
        }
    })

    // // PM 14:30 我共享字串出去
    // res.send('cors確認中112233');
})

app.post('/pokemon', express.urlencoded() ,function(req, res){
    // console.log(req.body.orange); // 橘子姊姊
    var sql = 'insert into pokemon (pokename) values (?)';
    pikachu.query(sql, [req.body.orange] ,function(err, data){
        if (err) {
            res.send('抱歉，新增有問題');
        } else {
            res.send(req.body.orange + '新增成功');
        }
    })
})

app.delete('/pokemon', express.urlencoded() ,function(req, res){
    var sql = 'delete from pokemon where id = ?'
    pikachu.query(sql, [req.body.banana] ,function(err, data){
        if (err) {
            res.send('抱歉，刪除有問題');
        } else {
            res.send(req.body.banana + '刪除成功');
        }
    })
})

app.put('/pokemon', express.urlencoded() ,function(req, res){
    var sql = 'update pokemon set pokename = ? where id = ?'
    pikachu.query(sql, [req.body.pokename, req.body.id] ,function(err, data){
        if (err) {
            res.send('抱歉，更新有問題');
        } else {
            res.send(req.body.id + '更新成功');
        }
    })
})

// 啟動服務
app.listen(3000, function () {
    console.clear();
    console.log('3000 啟動中 ' + new Date().toLocaleTimeString());
})